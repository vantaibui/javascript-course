/**
 * Global scope
 * Local scope
 * Block scope
 * Lexical scope
 */
