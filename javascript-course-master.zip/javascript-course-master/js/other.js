// Undefined -> Khai báo nhưng chưa gán giá trị
let a;
console.log(a); // undefined
let b;
console.log(b);
b = 100;
console.log(b);
const c = "String";
// Null -> nothing
let d = null;
console.log(d);
// Boolean -> true or false
// falsy values vs truthy values
// falsy values: "", 0, false, undefined, null
// truthy values: "abc", 1, true, 100, 1000
