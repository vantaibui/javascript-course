// document.addEventListener("DOMContentLoaded")
window.addEventListener("load", function () {
  console.log("your web loaded");
});
document.addEventListener("DOMContentLoaded", function () {
  console.log("DOM loaded");
});
// window.addEventListener("load")
// web fully loaded
